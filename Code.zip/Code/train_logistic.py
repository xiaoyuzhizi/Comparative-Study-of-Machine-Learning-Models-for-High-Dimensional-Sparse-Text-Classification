import numpy as np
import pickle
import joblib

import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import KFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score

from bayes_opt import BayesianOptimization

# =============== 1. 数据加载 ===============
def load_data():
    """
    加载特征和标签数据
    """
    print("正在加载数据...")
    with open('train_feature.pkl', 'rb') as f:
        X = pickle.load(f)
    y = np.load('train_labels.npy')
    return X, y

# =============== 2. 定义带有方差-偏差估计的目标函数 ===============
def bayesian_optimization(
    X, 
    y, 
    init_points=5, 
    n_iter=20, 
    cv_splits=5,
    bias_variance_weight=0.1
):
    """
    使用 Bayesian Optimization 进行超参数优化，考虑方差-偏差
    bias_variance_weight: λ，用于平衡准确率和(偏差 + 方差)之间的权衡
    """
    opt_log = []

    def logistic_cv(C_log_scale):
        C = 10 ** C_log_scale
        acc_list, bias_list, var_list = [], [], []

        kf = KFold(n_splits=cv_splits, shuffle=True, random_state=42)
        for train_idx, test_idx in kf.split(X):
            X_train, X_test = X[train_idx], X[test_idx]
            y_train, y_test = y[train_idx], y[test_idx]

            model = LogisticRegression(
                C=C,
                solver='saga',
                max_iter=2000,
                random_state=42,
                n_jobs=-1
            )
            model.fit(X_train, y_train)

            y_pred = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)[:, 1]

            acc = accuracy_score(y_test, y_pred)
            acc_list.append(acc)

            mean_pred = np.mean(y_pred_proba)
            mean_true = np.mean(y_test)
            bias = (mean_pred - mean_true) ** 2
            var = np.var(y_pred_proba)

            bias_list.append(bias)
            var_list.append(var)

        mean_acc = np.mean(acc_list)
        mean_bias = np.mean(bias_list)
        mean_var = np.mean(var_list)
        objective_value = mean_acc - bias_variance_weight * (mean_bias + mean_var)

        opt_log.append({
            'C_log_scale': C_log_scale,
            'C': C,
            'acc': mean_acc,
            'bias': mean_bias,
            'var': mean_var,
            'objective': objective_value
        })

        print(f"[BayesOpt] C=10^{C_log_scale:.4f}={C:.5f}, Acc={mean_acc:.4f}, "
              f"Bias={mean_bias:.6f}, Var={mean_var:.6f}, Obj={objective_value:.4f}")
        
        return objective_value
    
    pbounds = {'C_log_scale': (-4, 2)}

    optimizer = BayesianOptimization(
        f=logistic_cv,
        pbounds=pbounds,
        random_state=42,
        verbose=2
    )
    
    optimizer.maximize(init_points=init_points, n_iter=n_iter)
    log_df = pd.DataFrame(opt_log)
    return optimizer, log_df


# =============== 3. 训练流程（主函数） ===============
# 可视化降维后的数据
def plot_pca_2d(X_reduced, y):
    """
    绘制降维后的二维散点图
    """
    plt.figure(figsize=(10, 8))
    scatter = plt.scatter(
        X_reduced[:, 0], X_reduced[:, 1], c=y, cmap='viridis', alpha=0.7
    )
    plt.colorbar(scatter, label="Class Label")
    plt.xlabel("Principal Component 1")
    plt.ylabel("Principal Component 2")
    plt.title("PCA Visualization (2D)")
    plt.grid(True)
    plt.show()

# 修改主函数，加入可视化部分
def train_linear_model():
    X, y = load_data()

    # 1. 特征标准化
    scaler = StandardScaler(with_mean=False)
    X_scaled = scaler.fit_transform(X)

    # 2. 特征降维
    print("\n开始进行 PCA 降维...")
    n_components = 50  # 可以调整为需要的主成分数量
    pca = PCA(n_components=n_components)
    X_reduced = pca.fit_transform(X_scaled)
    print(f"PCA 降维完成，保留主成分数量: {n_components}")

    # ========== 绘制 PCA 降维后的二维散点图 ==========
    if n_components >= 2:
        print("\n可视化降维后的数据 (前两主成分)...")
        plot_pca_2d(X_reduced, y)
    else:
        print("\n降维至小于2维，无法绘制二维散点图。")

    # 3. 使用 Bayesian Optimization 进行超参数优化
    print("\n开始使用 Bayesian Optimization 进行超参数优化(结合方差-偏差分析)...")
    optimizer, log_df = bayesian_optimization(
        X_reduced, 
        y, 
        init_points=5, 
        n_iter=20, 
        cv_splits=5, 
        bias_variance_weight=0.1
    )

    best_params = optimizer.max['params']
    best_C = 10 ** best_params['C_log_scale']
    print(f"\n[BayesOpt] 最佳参数: C = {best_C:.6f} (10^{best_params['C_log_scale']:.4f}), solver = saga")

    # 4. 使用最佳参数在全数据集上训练最终模型
    print("\n开始使用最佳参数训练最终模型...")
    final_model = LogisticRegression(
        C=best_C,
        solver='saga',
        max_iter=2000,
        random_state=42,
        n_jobs=-1
    )
    final_model.fit(X_reduced, y)

    # 5. 保存模型和处理器
    print("保存最终模型、标准化器和 PCA...")
    joblib.dump(final_model, 'linear_model_bayes_opt.joblib')
    joblib.dump(scaler, 'scaler.joblib')
    joblib.dump(pca, 'pca.joblib')
    print("模型训练完成并保存。")

    # 可视化结果
    log_df_sorted = log_df.sort_values(by='C')
    plt.figure(figsize=(10, 6))
    plt.plot(log_df_sorted['C'], log_df_sorted['acc'], label='Accuracy', marker='o')
    plt.plot(log_df_sorted['C'], log_df_sorted['bias'], label='Bias', marker='o')
    plt.plot(log_df_sorted['C'], log_df_sorted['var'], label='Variance', marker='o')
    plt.plot(log_df_sorted['C'], log_df_sorted['objective'], label='Objective', marker='o')
    plt.xscale('log')
    plt.xlabel("C (Log Scale)")
    plt.ylabel("Metric")
    plt.title("Bias-Variance-Accuracy-Objective vs C")
    plt.legend()
    plt.grid(True)
    plt.show()

    return final_model

if __name__ == "__main__":
    train_linear_model()