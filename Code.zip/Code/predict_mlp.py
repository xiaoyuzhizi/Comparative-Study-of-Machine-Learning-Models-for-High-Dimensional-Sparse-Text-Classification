import torch
import pickle
import numpy as np
import pandas as pd
from train_model import DeepModel  # 导入之前定义的模型结构
from scipy import sparse

def get_device():
    if torch.cuda.is_available():
        device_id = 0
        return torch.device(f'cuda:{device_id}')
    return torch.device('cpu')

def load_test_data(test_file):
    with open(test_file, 'rb') as f:
        test_features = pickle.load(f)
    return test_features

def predict():
    # 设置设备
    device = get_device()
    print(f'使用设备: {device}')
    
    # 加载测试数据
    test_features = load_test_data('test_feature.pkl')
    
    # 获取输入特征维度
    if sparse.issparse(test_features):
        input_size = test_features.shape[1]
    else:
        input_size = test_features[0].shape[0]
    
    # 初始化模型，添加 num_classes 参数
    model = DeepModel(input_size, num_classes=20).to(device)
    
    # 加载完整的checkpoint
    checkpoint = torch.load('trained_model.pth')
    model.load_state_dict(checkpoint['model_state_dict'])
    
    # 设置为评估模式
    model.eval()
    
    # 存储预测结果
    predictions = []
    
    # 批量预测
    with torch.no_grad():
        for i in range(test_features.shape[0]):
            # 处理稀疏矩阵
            if sparse.issparse(test_features):
                feature = torch.FloatTensor(test_features[i].toarray()).squeeze()
            else:
                feature = torch.FloatTensor(test_features[i])
            
            # 转换为tensor并移到指定设备
            feature_tensor = feature.unsqueeze(0).to(device)
            # 预测
            output = model(feature_tensor)
            # 获取最可能的类别
            _, predicted = torch.max(output.data, 1)
            predictions.append(predicted.item())
    
    # 创建提交文件
    submission = pd.DataFrame({
        'ID': range(len(predictions)),
        'label': predictions
    })
    
    # 保存为CSV文件
    submission.to_csv('submission.csv', index=False)
    print('预测完成，结果已保存到 submission.csv')

if __name__ == '__main__':
    predict() 