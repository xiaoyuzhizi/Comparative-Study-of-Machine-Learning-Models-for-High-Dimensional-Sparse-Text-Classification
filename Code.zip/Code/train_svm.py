import numpy as np
import pickle
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
from bayes_opt import BayesianOptimization
import joblib


def load_data():
    """
    加载特征和标签数据
    """
    print("正在加载数据...")
    with open('train_feature.pkl', 'rb') as f:
        X = pickle.load(f)
    y = np.load('train_labels.npy')
    return X, y


def bayesian_optimization(X, y, init_points=5, n_iter=20):
    """
    使用 Bayesian Optimization 进行超参数优化
    """
    def svm_cv(C, gamma):
        """
        SVM 的目标函数
        """
        C = 10 ** C  # 将 C 转换为对数尺度
        gamma = 10 ** gamma  # 将 gamma 转换为对数尺度
        model = SVC(kernel='rbf', C=C, gamma=gamma, random_state=42)

        # 使用交叉验证评估性能
        scores = cross_val_score(model, X, y, cv=5, scoring='accuracy', n_jobs=-1)
        return scores.mean()

    # 定义优化边界
    pbounds = {
        'C': (-3, 3),       # C 的对数范围 [10^-3, 10^3]
        'gamma': (-4, 1)    # gamma 的对数范围 [10^-4, 10^1]
    }

    # 初始化 Bayesian Optimization
    optimizer = BayesianOptimization(
        f=svm_cv,
        pbounds=pbounds,
        random_state=42,
        verbose=2
    )

    # 运行优化
    optimizer.maximize(init_points=init_points, n_iter=n_iter)
    return optimizer


def train_svm_model():
    # ------------------ 1. 加载数据 ------------------
    X, y = load_data()

    # ------------------ 2. 特征标准化 ------------------
    scaler = StandardScaler(with_mean=False)  # 修改这里：不进行中心化
    X_scaled = scaler.fit_transform(X)

    # ------------------ 3. Bayesian Optimization ------------------
    print("\n开始使用 Bayesian Optimization 进行超参数优化...")
    optimizer = bayesian_optimization(X_scaled, y)

    # 获取最佳参数
    best_params = optimizer.max['params']
    best_C = 10 ** best_params['C']  # 将对数尺度的 C 转换为实际值
    best_gamma = 10 ** best_params['gamma']  # 将对数尺度的 gamma 转换为实际值
    print("\n最佳参数: C={:.4f}, gamma={:.4f}".format(best_C, best_gamma))

    # ------------------ 4. 使用最佳参数在全数据集上训练 ------------------
    print("\n开始使用最佳参数训练最终模型...")
    final_model = SVC(
        kernel='rbf',
        C=best_C,
        gamma=best_gamma,
        random_state=42
    )
    final_model.fit(X_scaled, y)

    # ------------------ 5. 保存模型和标准化器 ------------------
    print("保存最终模型和标准化器...")
    joblib.dump(final_model, 'svm_model_bayes_opt.joblib')
    joblib.dump(scaler, 'scaler.joblib')
    print("模型训练完成并保存")

    return final_model


if __name__ == "__main__":
    train_svm_model()