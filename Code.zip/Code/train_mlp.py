import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import pickle
from torch.utils.data import Dataset, DataLoader
from scipy import sparse
from bayes_opt import BayesianOptimization
from sklearn.model_selection import KFold
from sklearn.preprocessing import StandardScaler
import joblib  # <- 引入joblib库

# 获取设备
def get_device():
    if torch.cuda.is_available():
        device_id = 0
        return torch.device(f'cuda:{device_id}')
    return torch.device('cpu')


# 自定义数据集类
class CustomDataset(Dataset):
    def __init__(self, features_path, labels_path):
        with open(features_path, 'rb') as f:
            self.features = pickle.load(f)
        self.labels = np.load(labels_path)

        # 统计样本数
        if sparse.issparse(self.features):
            self.num_samples = self.features.shape[0]
        else:
            self.num_samples = len(self.features)

    def __len__(self):
        return self.num_samples

    def __getitem__(self, idx):
        # 如果是稀疏矩阵，则取出该行并转为 dense，再转成 FloatTensor
        if sparse.issparse(self.features):
            feature = torch.FloatTensor(self.features[idx].toarray()).squeeze()
        else:
            feature = torch.FloatTensor(self.features[idx])

        label = torch.LongTensor([self.labels[idx]]).squeeze()
        return feature, label


# 定义神经网络模型
class DeepModel(nn.Module):
    def __init__(self, input_size, num_classes=20, dropout1=0.3, dropout2=0.2):
        super(DeepModel, self).__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_size, 256),
            nn.ReLU(),
            nn.Dropout(dropout1),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(dropout2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Linear(64, num_classes),
        )

    def forward(self, x):
        return self.layers(x)


def bayesian_objective(lr, dropout1, dropout2):
    """
    贝叶斯优化目标函数：
    - lr: 学习率 (对数空间)
    - dropout1, dropout2: 两个 Dropout 的参数
    """
    lr = 10 ** lr  # 学习率取对数尺度
    dropout1, dropout2 = float(dropout1), float(dropout2)

    # 5 折交叉验证
    kfold = KFold(n_splits=5, shuffle=True, random_state=42)
    val_accuracies = []

    for train_idx, val_idx in kfold.split(dataset):
        # 划分训练集和验证集
        train_data = DataLoader(
            torch.utils.data.Subset(dataset, train_idx),
            batch_size=32,
            shuffle=True
        )
        val_data = DataLoader(
            torch.utils.data.Subset(dataset, val_idx),
            batch_size=32,
            shuffle=False
        )

        # 初始化模型、损失函数和优化器
        model = DeepModel(
            input_size=input_size,
            num_classes=20,
            dropout1=dropout1,
            dropout2=dropout2
        ).to(device)
        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=lr)

        # 训练模型（每次只训练少量 epoch 用于快速评估）
        model.train()
        for epoch in range(3):
            for features, labels in train_data:
                features, labels = features.to(device), labels.to(device)
                optimizer.zero_grad()
                outputs = model(features)
                loss = criterion(outputs, labels)
                loss.backward()
                optimizer.step()

        # 验证模型
        model.eval()
        correct, total = 0, 0
        with torch.no_grad():
            for features, labels in val_data:
                features, labels = features.to(device), labels.to(device)
                outputs = model(features)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

        val_accuracies.append(correct / total)

    return np.mean(val_accuracies)


def bayesian_optimization():
    """
    使用 BayesianOptimization 进行超参数搜索
    """
    pbounds = {
        'lr': (-5, -2),        # 学习率范围 [10^-5, 10^-2]
        'dropout1': (0.1, 0.5),
        'dropout2': (0.1, 0.5),
    }

    optimizer = BayesianOptimization(
        f=bayesian_objective,
        pbounds=pbounds,
        random_state=42,
        verbose=2,
    )
    # 初始化 5 个随机点，之后迭代 20 次
    optimizer.maximize(init_points=5, n_iter=20)
    return optimizer


def main():
    global device, input_size, dataset
    device = get_device()
    print(f'使用设备: {device}')

    # 1. 加载数据
    dataset = CustomDataset('train_feature.pkl', 'train_labels.npy')

    # 2. 对高维稀疏数据进行标准化
    #    - 如果是稀疏矩阵需要设置 with_mean=False，否则可能会导致内存占用过高或报错
    if sparse.issparse(dataset.features):
        scaler = StandardScaler(with_mean=False)
        dataset.features = scaler.fit_transform(dataset.features)
    else:
        scaler = StandardScaler()
        dataset.features = scaler.fit_transform(dataset.features)
    # 3. 保存 scaler，以便预测时加载
    joblib.dump(scaler, 'scaler.joblib')
    print("[信息] 标准化器已保存到 scaler.joblib")


    # 3. 获取输入特征维度
    if sparse.issparse(dataset.features):
        input_size = dataset.features.shape[1]
    else:
        # dataset[0] -> (feature, label)
        sample_feature, _ = dataset[0]
        input_size = sample_feature.shape[0]

    # 4. 使用贝叶斯优化找到最佳超参数
    print("\n[贝叶斯优化] 开始搜索最佳超参数...")
    optimizer = bayesian_optimization()
    best_params = optimizer.max['params']
    best_lr = 10 ** best_params['lr']
    best_dropout1 = best_params['dropout1']
    best_dropout2 = best_params['dropout2']

    print("\n[结果] 最佳超参数:")
    print(f"  学习率: {best_lr:.6f}")
    print(f"  Dropout1 概率: {best_dropout1:.2f}")
    print(f"  Dropout2 概率: {best_dropout2:.2f}")

    # 5. 用最佳超参数训练最终模型
    print("\n[最终模型] 使用最佳超参数在完整数据集上训练...")
    model = DeepModel(
        input_size=input_size,
        num_classes=20,
        dropout1=best_dropout1,
        dropout2=best_dropout2
    ).to(device)

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=best_lr)
    full_loader = DataLoader(dataset, batch_size=32, shuffle=True)

    model.train()
    for epoch in range(10):  # 训练更多epoch
        total_loss = 0.0
        for features, labels in full_loader:
            features, labels = features.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(features)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

        print(f'Epoch {epoch+1}, Loss: {total_loss / len(full_loader):.4f}')

    # 6. 保存最终模型
    torch.save(model.state_dict(), 'final_mlp_model.pth')
    print('\n[信息] 最终模型已保存到 final_mlp_model.pth')


if __name__ == '__main__':
    main()