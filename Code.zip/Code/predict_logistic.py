import numpy as np
import pickle
import joblib
import pandas as pd

def load_test_data():
    """
    加载测试数据
    """
    print("正在加载测试数据...")
    with open('test_feature.pkl', 'rb') as f:
        X_test = pickle.load(f)
    return X_test

def predict():
    # 加载测试数据
    X_test = load_test_data()
    
    # 加载保存的模型、标准化器和PCA
    print("加载模型、标准化器和PCA...")
    model = joblib.load('linear_model_bayes_opt.joblib')
    scaler = joblib.load('scaler.joblib')
    pca = joblib.load('pca.joblib')
    
    # 对测试数据进行标准化
    print("正在进行数据预处理...")
    X_test_scaled = scaler.transform(X_test)
    
    # 使用PCA进行降维
    print("正在进行PCA降维...")
    X_test_reduced = pca.transform(X_test_scaled)
    
    # 进行预测
    print("正在进行预测...")
    predictions = model.predict(X_test_reduced)
    
    # 创建提交文件
    submission = pd.DataFrame({
        'ID': range(len(predictions)),
        'label': predictions
    })
    
    # 保存为CSV文件
    submission.to_csv('submission.csv', index=False)
    print('预测完成，结果已保存到 submission.csv')

if __name__ == '__main__':
    predict()